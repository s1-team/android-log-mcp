android-log-mcp diagnostic report

manifest.json                 parameters, sizes, redaction counts, warnings
note.txt                      the reporter's description (if given)
store/v1/<device-id>/         recorded data in the tool's own format; load with
                                android-log-mcp --offline <unzipped>/store
devices/<serial>/device.json  build fingerprint, model, SDK, zone offset, boot id
devices/<serial>/logcat/<boot>.txt
                              the same records as raw "logcat -v threadtime -v epoch -v uid
                              -v usec -v printable" text (replayable)
devices/<serial>/dropbox/<tag>.txt
                              DropBox crash / ANR / tombstone entries in the window
devices/<serial>/am-start.txt output of "am start -W" (only with --am-start)
diagnostics/service.log       the service log (last 1 MiB, redacted); crash.log, service.json,
                              diagnose.txt (who holds the lock, is the socket there) and
                              adb-devices.txt ("adb devices -l") when available.
                              With --logs-only this is all the zip contains.

Sensitive values are replaced by [REDACTED:<type>#<n>] unless the report was
made with --no-redact (see manifest.json "redaction"). Redaction is pattern
based: review the files before sharing them publicly.
